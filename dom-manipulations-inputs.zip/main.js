document.querySelector("#reset-field button").addEventListener('click',function(){
  // TASK #1

})


document.querySelector("#validate-field button").addEventListener('click',function(){
  // TASK #2

})


document.querySelector("#calculate-items button").addEventListener('click',function(){
  // TASK #3

})


document.querySelector("#select-to-show-more button").addEventListener('click',function(){
  // TASK #4

})
